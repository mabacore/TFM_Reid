Airport dataset
-----------------
RESEARCH USE ONLY
-----------------
Please cite the following paper if you use this dataset in your research:
@article{karanam2016systematic,
  title={A Systematic Evaluation and Benchmark for Person Re-Identification: Features, Metrics, and Datasets},
  author={Karanam, Srikrishna and Gou, Mengran and Wu, Ziyan and Rates-Borras, Angels and Camps, Octavia and Radke, Richard J},
  journal={arXiv preprint arXiv:1605.09653},
  year={2016}
}

# *.txt
camID       - camera number for each crop image 
personID    - ground truth ID for each crop image
            0: false alarms from person detector
            [11001,401999]: valid and reappearing IDs
            [1320011,inf] no reappearing IDs
timeID      - time stamp ID for each crop image
filepath    - path to each cropped image

# Partition_airport.mat
Camera 37 is fixed as the target camera. Test is applied per time stamp per gallery camera.
idx_train   - index of train samples
idx_test    - index of test samples
idx_probe   - index of probe samples in test 
idx_gallery - index of gallery samples in test
ix_pos_pair - index of pre-generated positive pairs
ix_neg_pair - index of pre-generated negtive pairs
galCam      - gallery camera ID